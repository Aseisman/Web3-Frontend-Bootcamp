import React from "react";

// Header 组件  展示应用标题

function Header(){
    return (
        <header>
            <h1>待办事项</h1>
        </header>
    );
    
}
export default Header;
